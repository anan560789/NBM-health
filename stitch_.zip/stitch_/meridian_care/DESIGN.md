```markdown
# Design System Strategy: The Empathetic Authority

## 1. Overview & Creative North Star
This design system is anchored by a Creative North Star we call **"The Empathetic Authority."** In the realm of healthcare education, we must balance clinical precision with the warmth of human care. We are moving away from the "cold clinic" aesthetic—characterized by harsh white backgrounds and rigid grids—and toward a high-end editorial experience that feels curated, breathable, and deeply intentional.

The system breaks the "template" look through **intentional asymmetry** and **tonal depth**. Rather than using traditional boxes to house content, we use expansive white space and overlapping elements to create a sense of rhythm. This approach mimics a premium medical journal where the information is authoritative but the presentation is inviting.

## 2. Color & Surface Philosophy
The palette utilizes a sophisticated mix of "Trustworthy Teal" and "Gentle Peach" to bridge the gap between science and soul.

### The "No-Line" Rule
To achieve a signature, premium feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` (`#f4f4f0`) section should sit against a `background` (`#faf9f5`) to create a soft, organic transition.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers, like stacked sheets of fine, heavy-weight paper. 
- **The Base:** Use `surface` (`#faf9f5`) for the primary canvas.
- **The Inset:** Use `surface_container` (`#efeeea`) or `surface_container_high` (`#e9e8e4`) to pull the eye toward specific modules or instructional blocks.
- **The Focal Point:** Use `surface_container_lowest` (`#ffffff`) for cards or interactive elements to make them appear to "float" naturally above the warmer background.

### The "Glass & Gradient" Rule
Standard flat colors can feel sterile. For main CTAs or Hero backgrounds, utilize subtle gradients transitioning from `primary` (`#006067`) to `primary_container` (`#007b83`). For floating navigation or overlay panels, apply **Glassmorphism**: use semi-transparent surface tokens with a `backdrop-blur` of 20px-40px to allow the warm peach or teal tones to bleed through, softening the interface.

## 3. Typography: Editorial Clarity
We use a dual-typeface system to signal both modern tech and medical tradition.

*   **Lexend (Display & Headlines):** This font provides an approachable, geometric clarity. Use `display-lg` (3.5rem) with tighter letter-spacing for a bold, editorial look that feels authoritative yet soft due to its rounded nature.
*   **Inter (Body & Labels):** The workhorse for medical clarity. Inter provides high legibility for dense educational content. Use `body-lg` (1rem) for primary learning modules to ensure eye comfort during long reading sessions.

**Hierarchy Note:** Always lead with a significant contrast between `headline-lg` and `body-md`. This gap creates the "High-End" look, emphasizing the headline as a statement of fact and the body as a supportive explanation.

## 4. Elevation & Depth
In this design system, depth is a tool for focus, not just decoration.

*   **The Layering Principle:** Avoid shadows where possible. Instead, stack your surface tiers. A `surface_container_lowest` card placed on a `surface_container_low` section creates a "soft lift" that feels architectural rather than digital.
*   **Ambient Shadows:** If an element must float (like a FAB or a Tooltip), use a shadow with a 32px-64px blur and 4%-6% opacity. The shadow color should be a tinted version of `on_surface` (`#1b1c1a`), never a neutral grey.
*   **The "Ghost Border" Fallback:** If accessibility requirements demand a container edge, use the "Ghost Border" method: use the `outline_variant` (`#bdc9ca`) at 15% opacity. It should be felt, not seen.

## 5. Components

### Buttons
*   **Primary:** A soft gradient from `primary` to `primary_container`. Use `rounded-full` (9999px) for a "warm" medical feel. 
*   **Secondary:** `surface_container_highest` background with `on_secondary_container` text. No border.
*   **States:** On hover, increase the gradient intensity; on press, use a subtle `primary_fixed_dim` inner glow.

### Input Fields
*   **Style:** Avoid the "box" look. Use a `surface_container_low` fill with a `rounded-md` (0.75rem) corner. 
*   **Indicator:** Instead of a full-border change on focus, use a 2px bottom-bar in `primary` or a subtle `outline` shift.

### Cards & Lists
*   **Forbidden:** 1px divider lines. 
*   **The Alternative:** Separate list items using vertical white space (use the `1rem` or `1.5rem` spacing tokens) or alternating background tints between `surface` and `surface_container_lowest`.

### Signature Component: The "Learning Orb"
A specialized progress indicator for students. Use a large, blurred `tertiary_container` (`#a35c44`) glow behind a `secondary` (`#376474`) circular progress ring. This creates a "human-centric" glowing effect that feels more like a living organism than a clinical chart.

## 6. Do's and Don'ts

| Do | Don't |
| :--- | :--- |
| **Do** use `tertiary` (Peach) accents for "human" moments: notifications, achievements, or user avatars. | **Don't** use `tertiary` for functional medical data; stick to the `primary` (Teal) for authority. |
| **Do** lean into `rounded-lg` (1rem) and `rounded-xl` (1.5rem) for containers to maintain the "warm" vibe. | **Don't** use `rounded-none`. Sharp corners feel aggressive and overly clinical in this context. |
| **Do** use asymmetric layouts where text is offset from imagery to create a premium editorial feel. | **Don't** center-align everything. It looks like a standard template and loses the custom feel. |
| **Do** use `surface_dim` for subtle background transitions in dark mode or deep focus areas. | **Don't** use pure black `#000000`. It breaks the "Warm White" foundation of the system. |

### Accessibility Reminder
While we prioritize "Ghost Borders" and Tonal Layering, ensure that all text-to-background contrast ratios meet WCAG AA standards. Use `on_surface_variant` for secondary text to ensure legibility against the warm `surface` tones.```